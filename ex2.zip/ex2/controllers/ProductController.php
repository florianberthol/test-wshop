<?php
namespace FwTest\Controller;
use FwTest\Classes as Classes;

class ProductController extends AbstractController
{
    /**
     * @Route('/product_list')
     */
    public function index()
    {
    	$db = $this->getDatabaseConnection();

        $list_product = Classes\ProductAction::getAll($db, 0, $this->array_constant['product']['nb_products']);

        echo $this->render('product/list.tpl', ['list_product' => $list_product]);

    }

    /**
     * @Route('/product_detail')
     */
    public function detail()
    {
        $db = $this->getDatabaseConnection();

    	$id = (isset($_GET['id']) && !empty($_GET['id']))? $_GET['id']:0;

    	if (!empty($id)) {

    		$product = new Classes\ProductAction($db, $id);

    		if (!empty($product)) {
    			echo $this->render('product/detail.tpl', ['product' => $product]);
    		} else {
    			$this->_redirect('product_list');
    		}
    		
    	} else {
    		$this->_redirect('product_list');
    	}

    }
}