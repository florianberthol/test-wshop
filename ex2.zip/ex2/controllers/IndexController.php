<?php
namespace FwTest\Controller;

class IndexController extends AbstractController
{
    /**
     * @Route('/index')
     */
    public function index()
    {
        echo 'Index.';
    }
}