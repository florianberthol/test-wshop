Créer les tables produit et produit_lang à partir du fichier importSql.sql
Modifier le fichier config/database.ini
Configurer PHP pour afficher toutes les notices
Corriger les erreurs de code pour tout faire fonctionner

** Il est préférable d'utiliser une version PHP > 7.2

Bonne chance :)